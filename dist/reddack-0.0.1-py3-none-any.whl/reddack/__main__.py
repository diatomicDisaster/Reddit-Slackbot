#!/usr/bin/env python3

# Local imports
from modfromslack.cli import main

if __name__ == "__main__":
    """Run modfromslack through the CLI."""
    main()