# Reddack

<!-- Framework -->
[![PyPI Python version](https://img.shields.io/pypi/pyversions/reddack?label=Python)](https://pypi.org/project/submanager/)  <!-- markdown-link-check-disable-line -->
[![Framework](https://img.shields.io/badge/Framework-PRAW-orange.svg)](https://github.com/pytest-dev/pytest)
[![Framework](https://img.shields.io/badge/Framework-NGINX-brightgreen)](https://github.com/pytest-dev/pytest)
[![Framework](https://img.shields.io/badge/Framework-Slack-lightgrey)](https://github.com/pytest-dev/pytest)

<!-- Status -->
[![License](https://img.shields.io/github/license/diatomicDisaster/reddack?label=License)](https://github.com/r-spacex/submanager/blob/master/LICENSE.txt)
[![PyPI status](https://img.shields.io/pypi/status/reddack?label=Status)](https://pypi.org/project/submanager/)  <!-- markdown-link-check-disable-line -->
[![PyPI version](https://img.shields.io/pypi/v/reddack?label=PyPI)](https://pypi.org/project/submanager/)  <!-- markdown-link-check-disable-line -->
[![GitHub version](https://img.shields.io/github/v/tag/diatomicDisaster/reddack?include_prereleases&label=GitHub)](https://github.com/r-spacex/submanager/releases)

Reddack is a suite of tools for moderating Reddit communities via Slack, using interactive messages and the Slack Block framework.

Currently this package is in pre-release, and isn't quite suitable for public use yet - more information will be added shortly.
